#!/bin/bash
echo "Replace YOUR_ADDRESS, YOUR_NODE:YOUR_PORT to run the miner"
while :; do
    ./astrominer -w dero1qyjnxta0us8kuv80lrqm2dy483gsrmntty7yy7lzr3wldyf77tm4xqqsdhp6n -m 3 -r dero.rabidmining.com:10300 -r dero-eu.friendspool.club:10300 -p rpc;
    sleep 5;
done